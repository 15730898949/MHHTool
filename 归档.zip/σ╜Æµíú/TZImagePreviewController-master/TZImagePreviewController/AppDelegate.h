//
//  AppDelegate.h
//  TZImagePreviewController
//
//  Created by 谭真 on 2018/8/23.
//  Copyright © 2018 Alibaba. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

