//
//  main.m
//  TZImagePreviewController
//
//  Created by 谭真 on 2018/8/23.
//  Copyright © 2018 Alibaba. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
